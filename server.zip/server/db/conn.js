const { MongoClient } = require("mongodb");
const connectionString = process.env.ATLAS_URI;
const client = new MongoClient(connectionString, {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

let dbConnection;

module.exports = {
  connectToServer: async function (callback) {
    try{
      client.connect();
      dbConnection = client.db("daycare_db");
      return callback();
  }catch(err){
      console.log(err)
  }},
  //   MongoClient.connect(process.env.ATLAS_URI, {
  //     useNewUrlParser: true,
  //     useUnifiedTopology: true,
  //   }, (err, db) => {
      
  //     if (err || !db) {
  //       return callback(err);
  //     }

  //     dbConnection = db.db("daycare_db");
  //     console.log("Successfully connected to MongoDB.");

  //     return callback();
  //   });
  // },

  getDb: function () {
    return dbConnection;
  },
};